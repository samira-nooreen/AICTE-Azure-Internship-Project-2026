document.addEventListener("DOMContentLoaded", function () {
  const button = document.getElementById("detect-btn");
  const resultBox = document.getElementById("result-box");

  button.addEventListener("click", async () => {
    resultBox.innerHTML = "⏳ Running fraud detection...";

    try {
      const response = await fetch("/detect", {
        method: "POST",
      });

      const data = await response.json();
      resultBox.innerHTML = `<p>${data.result}</p>`;
    } catch (error) {
      resultBox.innerHTML = "❌ Error running detection.";
      console.error(error);
    }
  });
});
