from flask import Blueprint, render_template

mdfdp = Blueprint("mdfdp", __name__, template_folder="templates", static_folder="static")

@mdfdp.route("/")
def home():
    return render_template("index.html")
