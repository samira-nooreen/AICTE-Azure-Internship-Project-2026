from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/detect', methods=['POST'])
def detect():
    # --- your real logic goes here ---
    # for now, let’s simulate a result
    result = "✅ Fraud analysis complete: No fraud detected!"

    # return JSON so JavaScript can display it
    return jsonify({'result': result})

if __name__ == '__main__':
    app.run(debug=True)
